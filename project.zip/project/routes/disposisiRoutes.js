const express = require('express');
const router = express.Router();
const disposisiController = require('../controllers/disposisiController'); // Sesuaikan path ini sesuai dengan struktur proyek Anda

router.get('/disposisi', disposisiController.showDisposisi);
router.post('/create-disposisi', disposisiController.createDisposisi);
router.delete('/deleteDisposisi/:id', disposisiController.deleteDisposisi);

module.exports = router;
