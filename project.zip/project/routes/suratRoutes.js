const express = require('express');
const router = express.Router();
const suratController = require('../controllers/suratController');
const authenticate = require('../middlewares/authenticate');


const multer = require('multer');
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); 
  }, 
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});
const upload = multer({ storage });


router.post('/tambahsurat', upload.single('lampiran'), suratController.tambahSurat);
router.get('/suratmasuk', authenticate,suratController.showSuratMasuk);
router.get('/suratkeluar', authenticate,suratController.showSuratKeluar);
router.get('/tambahsurat', authenticate, suratController.showTambahSurat);
router.get('/deleteSuratMasuk/:id', authenticate, suratController.deleteSuratMasuk);
router.get('/deleteSuratKeluar/:id', authenticate, suratController.deleteSuratKeluar);
router.get('/editSurat/:id', authenticate,suratController.showEditSurat);
router.post('/editSurat/:id', upload.single('lampiran'), suratController.editSurat);


module.exports = router;
