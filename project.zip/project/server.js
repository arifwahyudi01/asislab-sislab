const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const path = require('path');
const app = express();
const port = 3000;
const { sequelize } = require('./models');
const userRoutes = require('./routes/userRoutes');
const suratRoutes = require('./routes/suratRoutes');
const disposisiRoutes = require('./routes/disposisiRoutes');

app.set('view engine', 'ejs'); 
// app.set('views', path.join(__dirname, 'views'));
app.set('views', './views'); 
app.use(express.static('public'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));



app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Pastikan secure diatur ke true di production
}));




// routes
app.use('/', userRoutes);
app.use('/', suratRoutes);
app.use('/', disposisiRoutes);








sequelize.sync({ force: false }) 
  .then(() => {
    console.log('Database synced');
  })
  .catch(err => {
    console.error('Failed to sync database:', err);
  });

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
