const db = require('../models');
const { Op } = require('sequelize');


exports.showSuratMasuk = async (req, res) => {
    try {
        const userId = req.session.user.id; // Ambil id user yang sedang login
        const surats = await db.Surat.findAll({
            where: { id_penerima: userId },
            include: {
                model: db.User, 
                as: 'pengirim', // Asumsikan ada asosiasi 'pengirim' di model Surat
                attributes: ['name']
            }
        });
        res.render('asisten/suratmasuk', { surats, userId });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};



exports.showSuratKeluar = async (req, res) => {
    try {
        const userId = req.session.user.id; 
        const surats = await db.Surat.findAll({
            where: { userId },
            include: {
                model: db.User, 
                as: 'penerima', 
                attributes: ['name'] 
            }
        });
        res.render('asisten/suratkeluar', { surats, userId });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};


 
exports.showTambahSurat = async (req, res) => {
    try {
        const userId = req.session.user.id; 
        const users = await db.User.findAll({
            where: {
                id: {
                    [Op.ne]: userId 
                }
            }
        });
        res.render('asisten/tambahsurat', { users, userId });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

exports.tambahSurat = async (req, res) => {
try {
    const { nomor_surat, perihal, agenda, tanggal_event, id_penerima } = req.body;
    let lampiran = null;
    
    if (req.file) {
        lampiran = req.file.filename; 
    }

    await db.Surat.create({
        nomor_surat,
        perihal,
        agenda,
        tanggal_event,
        lampiran,
        userId: req.session.user.id,
        id_penerima: id_penerima 
    });

    res.redirect('/suratkeluar');
} catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
}
};

exports.deleteSuratMasuk = async (req, res) => {
    try {
        const suratId = req.params.id; 

        // Cari surat berdasarkan id dan userId (untuk memastikan hanya user yang bisa menghapus suratnya sendiri)
        const surat = await db.Surat.findOne({
            where: {
                id: suratId,
            }
        });

        if (!surat) {
            return res.status(404).send('Surat not found');
        }

        // Hapus surat dari database
        await surat.destroy();

        res.redirect('/suratmasuk'); // Redirect kembali ke halaman surat keluar setelah berhasil menghapus
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};


exports.deleteSuratKeluar = async (req, res) => {
    try {
        const suratId = req.params.id; 

        // Cari surat berdasarkan id dan userId (untuk memastikan hanya user yang bisa menghapus suratnya sendiri)
        const surat = await db.Surat.findOne({
            where: {
                id: suratId,
            }
        });

        if (!surat) {
            return res.status(404).send('Surat not found');
        }

        // Hapus surat dari database
        await surat.destroy();

        res.redirect('/suratkeluar'); // Redirect kembali ke halaman surat keluar setelah berhasil menghapus
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};



exports.showEditSurat = async (req, res) => {
    try {
        const suratId = req.params.id; // Ambil id surat dari parameter URL

        // Cari surat berdasarkan id dan userId (untuk memastikan hanya user yang bisa mengedit suratnya sendiri)
        const surat = await db.Surat.findOne({
            where: {
                id: suratId
            }
        });

        if (!surat) {
            return res.status(404).send('Surat not found');
        }

        const userId = req.session.user.id; 
        const users = await db.User.findAll({
            where: {
                id: {
                    [Op.ne]: userId 
                }
            }
        });
        // Render halaman editSurat.ejs dengan data surat dan users
        res.render(`asisten/editSurat`, { surat, users });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};



exports.editSurat = async (req, res) => {
    try {
        const suratId = req.params.id; // Ambil id surat dari parameter URL
        const { nomor_surat, perihal, agenda, tanggal_event, id_penerima } = req.body;
        let lampiran = null;
        
        if (req.file) {
            lampiran = req.file.filename; // Jika ada lampiran baru, ambil nama filenya
        }
        
        // Cari surat berdasarkan id dan userId (untuk memastikan hanya user yang bisa mengedit suratnya sendiri)
        const surat = await db.Surat.findOne({
            where: {
                id: suratId
            }
        });
        
        if (!surat) {
            return res.status(404).send('Surat not found');
        }
        
        // Update data surat
        surat.nomor_surat = nomor_surat;
        surat.perihal = perihal;
        surat.agenda = agenda;
        surat.tanggal_event = tanggal_event;
        surat.id_penerima = id_penerima;
        
        if (lampiran) {
            surat.lampiran = lampiran; // Update lampiran hanya jika ada perubahan
        }
        
        await surat.save(); // Simpan perubahan data surat
        
        res.redirect('/suratkeluar'); // Redirect kembali ke halaman surat keluar setelah berhasil mengedit
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};