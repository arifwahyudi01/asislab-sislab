const db = require('../models'); 
const { Op } = require('sequelize');

exports.showDisposisi = async (req, res) => {
    try {
        const userId = req.session.user.id; // Get the userId from the current session
        
        // Get all disposition data based on the logged-in userId
        const disposisis = await db.Disposisi.findAll({
            where: {
                userId
            },
            include: [
                {
                    model: db.Surat,
                    as: 'surat'
                },
                {
                    model: db.User,
                    as: 'penerima', // Recipient
                    attributes: ['name']
                },
                {
                    model: db.User,
                    as: 'user', // Sender
                    attributes: ['name']
                }
            ]
        });

        res.render('asisten/disposisi', { disposisis, userId });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};


exports.createDisposisi = async (req, res) => {
    try {
        const { suratId, userId } = req.body;

        // Check if a disposisi already exists for this suratId and userId
        const existingDisposisi = await db.Disposisi.findOne({
            where: {
                id_surat: suratId,
                userId: userId
            }
        });

        if (existingDisposisi) {
            return res.status(400).json({ message: 'Surat ini sudah dikirim untuk disposisi.' });
        }

        // Find a user with the role of 'kordas'
        const kordas = await db.User.findOne({
            where: {
                role: 'kordas'
            }
        });

        if (!kordas) {
            return res.status(404).send('Kordas not found');
        }

        // Create the new Disposisi entry
        const newDisposisi = await db.Disposisi.create({
            userId,
            id_surat: suratId,
            id_penerima: kordas.id
        });

        res.status(201).json({ message: 'Disposisi created successfully!' });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};



exports.deleteDisposisi = async (req, res) => {
    try {
        const disposisiId = req.params.id;

        // Find the disposisi by ID
        const disposisi = await db.Disposisi.findByPk(disposisiId);

        if (!disposisi) {
            return res.status(404).send('Disposisi not found');
        }

        // Delete the disposisi
        await disposisi.destroy();

        res.status(200).json({ message: 'Disposisi deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};