module.exports = (sequelize, DataTypes) => {
    const Surat = sequelize.define('Surat', {
        nomor_surat: {
            type: DataTypes.STRING,
            allowNull: false
        },
        perihal: {
            type: DataTypes.STRING,
            allowNull: false
        },
        agenda: {
            type: DataTypes.TEXT, 
            allowNull: false
        },
        tanggal_event: {
            type: DataTypes.DATE,
            allowNull: false
        },
        lampiran: {
            type: DataTypes.STRING,
            allowNull: true
        }
    });

    Surat.associate = (models) => {
        Surat.belongsTo(models.User, { as: 'pengirim', foreignKey: 'userId' }); // Sender
        Surat.belongsTo(models.User, { as: 'penerima', foreignKey: 'id_penerima' }); // Recipient
        Surat.hasMany(models.Disposisi, { as: 'disposisi', foreignKey: 'id_surat', onDelete: 'CASCADE' });
    };

    return Surat;
};
