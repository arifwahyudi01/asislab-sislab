const { Sequelize, DataTypes } = require('sequelize');
const config = require('../config/config.json');

const sequelize = new Sequelize(config.development);

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.User = require('./user')(sequelize, DataTypes);
db.Surat = require('./surat')(sequelize, DataTypes);
db.Disposisi = require('./disposisi')(sequelize, DataTypes);

// Mengatur asosiasi model
Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});
 
// Sinkronisasi model
sequelize.sync({ force: false }).then(() => {
  console.log('Database & tables created!');
});
 
module.exports = db;
   