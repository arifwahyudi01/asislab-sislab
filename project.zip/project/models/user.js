module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define('User', {
      nim: {
          type: DataTypes.STRING,
          allowNull: false
      },
      name: {
          type: DataTypes.STRING,
          allowNull: false
      },
      email: {
          type: DataTypes.STRING,
          allowNull: false,
          unique: true,
          validate: {
              isEmail: true
          }
      },
      password: {
          type: DataTypes.STRING,
          allowNull: false
      },
      role: {
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: 'mahasiswa'
      }
  });

  User.associate = (models) => {
      User.hasMany(models.Surat, { as: 'pengirimSurat', foreignKey: 'userId', onDelete: 'CASCADE' });
      User.hasMany(models.Surat, { as: 'penerimaSurat', foreignKey: 'id_penerima', onDelete: 'CASCADE' });
      User.hasMany(models.Disposisi, { as: 'disposisiUser', foreignKey: 'userId', onDelete: 'CASCADE' });
      User.hasMany(models.Disposisi, { as: 'disposisiPenerima', foreignKey: 'id_penerima', onDelete: 'CASCADE' });
  };

  return User;
};
