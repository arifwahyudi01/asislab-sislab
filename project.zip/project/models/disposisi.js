module.exports = (sequelize, DataTypes) => {
    const Disposisi = sequelize.define('Disposisi', {
        userId: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        instruksi: {
            type: DataTypes.STRING,
            allowNull: true
        },
        saran: {
            type: DataTypes.STRING,
            allowNull: true
        },
        keputusan: {
            type: DataTypes.STRING,
            allowNull: true
        },
        id_surat: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        id_penerima: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    });

    Disposisi.associate = (models) => {
        Disposisi.belongsTo(models.User, { as: 'user', foreignKey: 'userId' }); // Sender
        Disposisi.belongsTo(models.Surat, { as: 'surat', foreignKey: 'id_surat' });
        Disposisi.belongsTo(models.User, { as: 'penerima', foreignKey: 'id_penerima' }); // Recipient
    };

    return Disposisi;
};
